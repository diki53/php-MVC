<div class="container mt-3">
  <h1>About Me</h1>
  <img src="<?= BASEURL; ?>/img/foto.jpeg" alt="Diki Romadoni" width="200" class="rounded-circle shadow">
  <p>Halo, nama saya <?= $data['nama']; ?>, umur saya <?= $data['umur']; ?> tahun. saya adalah seorang <?= $data['pekerjaan']; ?></p>
</div>