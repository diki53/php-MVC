<div class="container mt-3">
  <h3>Daftar Barang</h3>
  <div class="row">
    <div class="col-6">
      <ul class="list-group">
        <?php foreach ($data['brg'] as $brg) : ?>
          <li class="list-group-item d-flex justify-content-between">
            <?= $brg['nama_barang']; ?>
            <a href="<?= BASEURL; ?>/barang/detail/<?= $brg['id_barang']; ?>" class="badge badge-primary ">Detail</a>
          </li>
        <?php endforeach ?>
      </ul>
    </div>
  </div>
</div>