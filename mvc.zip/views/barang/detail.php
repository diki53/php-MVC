<div class="container mt-3 d-flex justify-content-center">
  <div class="card" style="width: 18rem;">
    <div class="card-header bg-info">
      <h5><?= $data['brg']['nama_barang']; ?></h5>
    </div>
    <div class="card-body">
      <h6 class="card-subtitle mb-2 text-muted"><?= $data['brg']['berat']; ?> Kg</h6>
      <p class="card-text"><?= $data['brg']['jumlah']; ?> <?= $data['brg']['satuan']; ?></p>
      <a href="<?= BASEURL; ?>/barang" class="card-link">Kembali</a>
    </div>
  </div>
</div>