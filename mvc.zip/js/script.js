$(function () {
  $('.tombolTambahData').on('click', function () {
    $('#formModalLabel').html('Tambah Data Pegawai');
    $('.modal-footer button[type=submit]').html('Tambah Data');
    $('.modal-body form').attr('action', 'http://localhost/parseUrl/pegawai/tambah')
    $('#nama').val('');
    $('#nip').val('');
    $('#email').val('');
    $('#posisi').val('');
    $('#id').val('');
  });




  $('.tampilModalUbah').on('click', function () {
    $('#formModalLabel').html('Ubah Data Pegawai');
    $('.modal-footer button[type=submit]').html('Ubah Data');
    $('.modal-body form').attr('action', 'http://localhost/parseUrl/pegawai/ubah')

    const id = $(this).data('id');


    $.ajax({
      url: 'http://localhost/parseUrl/pegawai/getubah',
      data: { id: id },
      method: 'post',
      dataType: 'json',
      success: function (data) {
        $('#nama').val(data.nama_pegawai);
        $('#nip').val(data.nip);
        $('#email').val(data.email);
        $('#posisi').val(data.posisi);
        $('#id').val(data.id_pegawai);

      }

    });

  });

});