<div class="container mt-3">
  <div class="card" style="width: 18rem;">
    <div class="card-body">
      <h5 class="card-title"><?= $data['pgw']['nama_pegawai']; ?></h5>
      <h6 class="card-subtitle mb-2 text-muted"><?= $data['pgw']['nip']; ?></h6>
      <p class="card-text"><?= $data['pgw']['email']; ?></p>
      <p class="card-text"><?= $data['pgw']['posisi']; ?></p>
      <a href="<?= BASEURL; ?>/pegawai" class="card-link">Kembali</a>
    </div>
  </div>
</div>