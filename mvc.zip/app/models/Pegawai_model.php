<?php

class Pegawai_model
{
  // private $pgw = [
  //   [
  //     "nama" => "Diki Romadoni",
  //     "nip" => "16201054",
  //     "email" => "diki@gmail.com",
  //     "posisi" => "Admin"
  //   ],
  //   [
  //     "nama" => "Dika Romadona",
  //     "nip" => "16201055",
  //     "email" => "dika@gmail.com",
  //     "posisi" => "Kurir"
  //   ],
  //   [
  //     "nama" => "Yadi",
  //     "nip" => "16201053",
  //     "email" => "yadi@gmail.com",
  //     "posisi" => "Admin"
  //   ]
  // ];

  private $table = 'tb_pegawai';
  private $db;

  public function __construct()
  {
    $this->db = new Database;
  }

  public function getAllPegawai()
  {

    $this->db->query("SELECT * FROM {$this->table}");
    return $this->db->resultSet();
  }

  public function getPegawaiById($id)
  {
    $this->db->query("SELECT * FROM {$this->table} WHERE id_pegawai=:id");
    $this->db->bind('id', $id);
    return $this->db->single();
  }

  public function tambahDataPegawai($data)
  {
    $query = "INSERT INTO tb_pegawai
                    VALUES
                    ('', :nama, :nip, '', :email, '', '', 'Aktif', :posisi, '')";

    $this->db->query($query);
    $this->db->bind('nama', $data['nama']);
    $this->db->bind('nip', $data['nip']);
    $this->db->bind('email', $data['email']);
    $this->db->bind('posisi', $data['posisi']);

    $this->db->execute();

    return $this->db->rowCount();
  }

  public function hapusDataPegawai($id)
  {
    $query = "DELETE FROM {$this->table} WHERE id_pegawai = :id";
    $this->db->query($query);
    $this->db->bind('id', $id);

    $this->db->execute();

    return $this->db->rowCount();
  }

  public function ubahDataPegawai($data)
  {
    $query = "UPDATE tb_pegawai
                    SET
                    nama_pegawai = :nama,
                    nip = :nip,
                    email = :email,
                    posisi = :posisi
                    WHERE id_pegawai = :id";

    $this->db->query($query);
    $this->db->bind('nama', $data['nama']);
    $this->db->bind('nip', $data['nip']);
    $this->db->bind('email', $data['email']);
    $this->db->bind('posisi', $data['posisi']);
    $this->db->bind('id', $data['id']);

    $this->db->execute();

    return $this->db->rowCount();
  }

  public function cariDataPegawai()
  {

    if (isset($_POST['keyword'])) {
      $keyword = $_POST['keyword'];
      $query = "SELECT * FROM tb_pegawai WHERE nama_pegawai LIKE :keyword";
      $this->db->query($query);
      $this->db->bind('keyword', "%$keyword%");

      return $this->db->resultSet();
    }

    $this->db->query("SELECT * FROM {$this->table}");
    return $this->db->resultSet();
  }
}
