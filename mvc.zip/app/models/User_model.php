<?php
class User_model
{
  private $nama = 'Diki Romadoni';

  public function getUser()
  {
    return $this->nama;
  }
}
